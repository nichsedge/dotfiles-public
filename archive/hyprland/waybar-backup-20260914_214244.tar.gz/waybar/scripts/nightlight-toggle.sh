#!/usr/bin/env bash
# Toggle gammastep night light. Called from waybar click + Hyprland keybind.
# ON = gammastep -O holds gamma via wlr-gamma-control and must stay resident.
# OFF = killing it is enough on wayland (compositor restores gamma); no gammastep -x needed.
if pgrep -f "gammastep.*-O" >/dev/null 2>&1; then
  pkill -f "gammastep.*-O" 2>/dev/null
  sleep 0.3
  pkill -x gammastep 2>/dev/null
else
  pkill -x gammastep 2>/dev/null
  nohup gammastep -O 3500 -P >/dev/null 2>&1 &
fi
# RTMIN+1 = signal 1 for custom/nightlight only (avoids full bar reload glitch)
pkill -RTMIN+1 waybar 2>/dev/null || pkill -SIGUSR2 waybar 2>/dev/null
