#!/usr/bin/env bash
# Delegate to primary tailscale-toggle script
exec /home/al/.config/scripts/tailscale-toggle.sh "$@"
