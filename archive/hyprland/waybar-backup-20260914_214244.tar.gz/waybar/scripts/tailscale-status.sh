#!/usr/bin/env bash
# Waybar tailscale status (return-type=json). Icon-only: TS with class up/down.
state=$(tailscale status --json 2>/dev/null | jq -r '.BackendState // "Stopped"')
if [ "$state" = "Running" ]; then
  ip=$(tailscale ip -4 2>/dev/null | head -1)
  jq -c -n --arg ip "${ip:-active}" '{text: "TS", class: "up", tooltip: ("Tailscale Connected\nIP: " + $ip + "\nClick to disconnect")}'
else
  jq -c -n '{text: "TS", class: "down", tooltip: "Tailscale Disconnected\nClick to connect"}'
fi
