#!/usr/bin/env bash
# Waybar nightlight status (return-type=json). Single-line JSON only.
if pgrep -f "gammastep.*-O" >/dev/null 2>&1; then
  jq -c -n '{text: "", class: "up", tooltip: "Night light ON (3500K)\nClick to turn off"}'
else
  jq -c -n '{text: "", class: "down", tooltip: "Night light OFF\nClick to turn on (3500K)"}'
fi
