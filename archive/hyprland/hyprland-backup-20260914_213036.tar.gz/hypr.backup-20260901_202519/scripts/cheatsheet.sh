#!/usr/bin/env bash
# Show shortcuts cheatsheet via wofi
cat << 'SHEET' | wofi --dmenu --prompt "⌨️ Hyprland Power-User Shortcuts" --width 900 --height 650
── ⚡ VIM NAVIGATION & WINDOW MOVING ──
⌘ H / J / K / L         Focus Left / Down / Up / Right
⌘ ⇧ H / J / K / L       Swap / Move Window Left / Down / Up / Right
⌘ ⇧ ← / → / ↑ / ↓       Directional Focus (Arrows)

── 📑 TABBED WINDOW GROUPS ──
⌘ G                     Group / Tabify Focused Window
⌘ [  /  ⌘ ]             Cycle Previous / Next Tab in Group
⌘ ⇧ G                   Extract / Eject Window from Group

── 🎛️ MODAL RESIZE SUBMAP ──
⌘ R                     Enter Resize Mode (H/J/K/L to resize, ESC to finish)

── 📐 RECTANGLE WINDOW MANAGEMENT ──
⌘ ⌥ ←  /  ⌃ ⌥ ←         Snap Left Half
⌘ ⌥ →  /  ⌃ ⌥ →         Snap Right Half
⌘ ⌥ ↑  /  ⌃ ⌥ ↑         Snap Top Half
⌘ ⌥ ↓  /  ⌃ ⌥ ↓         Snap Bottom Half
⌘ ⌥ U  /  ⌃ ⌥ U         Top-Left Quarter
⌘ ⌥ I  /  ⌃ ⌥ I         Top-Right Quarter
⌘ ⌥ J  /  ⌃ ⌥ J         Bottom-Left Quarter
⌘ ⌥ K  /  ⌃ ⌥ K         Bottom-Right Quarter
⌘ ⌥ ↩  /  ⌃ ⌥ ↩         Maximize (Keep Bar)
⌘ ⌥ F  /  ⌃ ⌥ F         Fullscreen Maximize
⌘ ⌥ C  /  ⌃ ⌥ C         Center Window
⌘ ⌥ ⌫  /  ⌃ ⌥ ⌫         Toggle Float / Restore

── 🚀 APPS, SCRATCHPADS & SYSTEM ──
⌘ Space                 Spotlight Search (Launcher)
⌘ ` (Tilde/Grave)       Quake Dropdown Terminal Scratchpad
⌘ M / ⌘ ⇧ M             Minimize Window / Restore Scratchpad
⌘ ⇧ Space / ⌘ ⇧ V       Clipboard History
⌘ ↩ / ⌘ T               Ghostty Terminal
⌘ N                     Finder / Files
⌘ B                     Default Web Browser
⌘ Q / ⌘ W               Close / Quit Window
⌘ S                     Toggle Dwindle Split Direction
⌘ Tab / ⌥ Tab           Cycle Windows
⌘ ⌥ ⎋ (Esc)             Activity Monitor (btop)
⌃ ⌘ Q / ⌃ ⌘ L         Lock Screen (macOS)
⌘ ⇧ Q                   Power / Session Menu
⌘ ⇧ 3 / 4 / 5           Screenshots (Full / Area / Window)
⌘ ,                     Edit Hyprland Config

── 🖥️ SPACES (WORKSPACES) ──
⌘ 1..9                  Jump to Space 1..9
⌘ ⌃ 1..9                Move Window to Space 1..9
⌃ ← / ⌃ →               Previous / Next Space
⌃ ↑ / ⌃ ↓               Scratchpad Toggle
3-Finger Swipe ↔        Trackpad Space Swipe
SHEET
