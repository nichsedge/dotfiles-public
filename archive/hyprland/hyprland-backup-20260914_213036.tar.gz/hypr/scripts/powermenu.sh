#!/usr/bin/env bash
# macOS-like Quick Session / Power Menu

options="🔒 Lock Screen\n🚪 Log Out\n🔄 Restart System\n🛑 Shut Down"
chosen=$(printf "%b" "$options" | wofi --dmenu --prompt " System Menu" --width 350 --height 280 --cache-file /dev/null)

case "$chosen" in
    *"Lock"*)
        pidof hyprlock || hyprlock
        ;;
    *"Log Out"*)
        if command -v uwsm >/dev/null 2>&1 && [ -n "$UWSM_INSTANCE" ]; then
            uwsm stop
        fi
        loginctl terminate-session "${XDG_SESSION_ID:-self}" 2>/dev/null || loginctl terminate-user "$USER" 2>/dev/null || killall -u "$USER" Hyprland
        ;;
    *"Restart"*)
        systemctl reboot
        ;;
    *"Shut Down"*)
        systemctl poweroff
        ;;
esac
