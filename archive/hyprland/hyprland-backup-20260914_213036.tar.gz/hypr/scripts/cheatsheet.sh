#!/usr/bin/env bash
# Show shortcuts cheatsheet via wofi
cat << 'SHEET' | wofi --dmenu --prompt "⌨️ Hyprland Power-User Shortcuts" --width 900 --height 650
── ⚡ VIM NAVIGATION & WINDOW MOVING ──
⌘ H / J / K / L         Focus Left / Down / Up / Right
⌘ ⇧ H / J / K / L       Swap / Move Window Left / Down / Up / Right
⌘ ⇧ ← / → / ↑ / ↓       Directional Focus (Arrows)

── 📑 TABBED WINDOW GROUPS ──
⌘ G                     Group / Tabify Focused Window
⌘ [  /  ⌘ ]             Cycle Previous / Next Tab in Group
⌘ ⇧ G                   Extract / Eject Window from Group

── 🎛️ MODAL RESIZE SUBMAP ──
⌘ R                     Enter Resize Mode (H/J/K/L to resize, ESC to finish)

── 📐 RECTANGLE WINDOW MANAGEMENT ──
⌘ ⌥ ←  /  ⌃ ⌥ ←         Snap Left Half
⌘ ⌥ →  /  ⌃ ⌥ →         Snap Right Half
⌘ ⌥ ↑  /  ⌃ ⌥ ↑         Snap Top Half
⌘ ⌥ ↓  /  ⌃ ⌥ ↓         Snap Bottom Half
⌘ ⌥ ↩  /  ⌃ ⌥ ↩         Maximize (Keep Bar)
⌘ ⌥ F  /  ⌃ ⌥ F         Fullscreen (Hide Bar)
⌘ ⌥ C  /  ⌃ ⌥ C         Center Window
⌘ ⌥ ⌫  /  ⌃ ⌥ ⌫         Toggle Float / Restore

── 🚀 APPS, SCRATCHPADS & SYSTEM ──
⌘ Space                 Spotlight Search (Launcher)
⌘ ` (Tilde/Grave)       Quake Dropdown Terminal Scratchpad
⌘ M / ⌘ ⇧ M             Minimize Window / Restore Scratchpad
⌘ V                     Clipboard History
⌘ ⇧ V                   Save Clipboard to Favorites
⌘ ⌃ V                   Manage Clips (pin old / preview / delete / wipe)
⌘ ↩ / ⌘ T               Ghostty Terminal
⌘ ⇧ T                   Tailscale VPN Menu
⌘ N                     New Empty Workspace
⌘ E                     Finder / Files
⌘ B                     Google Chrome
⌘ Q / ⌘ W               Close / Quit Window
⌘ S                     Toggle Dwindle Split Direction
⌘ Tab / ⌥ Tab           Cycle Windows
⌘ ⌥ ⎋ (Esc)             Activity Monitor (btop)
⌃ ⌘ Q / ⌃ ⌘ L         Lock Screen (macOS)
⌘ ⇧ Q                   Power / Session Menu
⌘ ⇧ 3 / 4 / 5           Screenshots (Full / Area / Window)
⌘ ,                     Edit Hyprland Config

── 🖥️ SPACES (WORKSPACES) ──
⌘ 1..9                  Jump to Space 1..9
⌘ ← / ⌘ →               Previous / Next Space
⌘ ↑                     Scratchpad Toggle (Mission Control)
3-Finger Swipe ↔        Trackpad Space Swipe
4-Finger Swipe (any)    Trackpad Space Swipe
SHEET
