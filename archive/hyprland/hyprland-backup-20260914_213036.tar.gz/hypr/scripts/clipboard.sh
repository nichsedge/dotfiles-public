#!/usr/bin/env bash
# Clipboard picker: pinned items first, then full history (text + labeled photos).
# Photos copy with a thumbnail preview notification — paste manually with Ctrl+V.
# Bound to SUPER+V.
PIN_DIR="$HOME/.config/clipboard_pins"
mkdir -p "$PIN_DIR"

PREV_CLASS=$(hyprctl activewindow -j 2>/dev/null | jq -r '.class // empty')

list=$(mktemp)
# Pinned section
for meta in "$PIN_DIR"/*.meta "$PIN_DIR"/*.txt; do
    [ -e "$meta" ] || continue
    id=$(basename "$meta" | cut -d. -f1)
    if [[ "$meta" == *.meta ]]; then
        # shellcheck disable=SC1090
        dims=$(grep -o 'dims=[^ ]*' "$meta" | cut -d= -f2)
        size=$(grep -o 'size=[^ ]*' "$meta" | cut -d= -f2)
        echo "📌 photo $dims $size ||PIN:$id" >> "$list"
    else
        label=$(head -1 "$meta" | head -c 60)
        echo "📌 $label ||PIN:$id" >> "$list"
    fi
done
# History section (newest first; photos already labeled with dims by cliphist)
cliphist list 2>/dev/null >> "$list"

selected=$(grep -v '^$' "$list" | wofi --dmenu --prompt "Clipboard (📌 pinned first)" --width 650 --height 450)
rm -f "$list"
[ -n "$selected" ] || exit 0

copy_file() { # $1=file $2=mime $3=label $4=thumb(optional)
    wl-copy --type "$2" < "$1"
    wl-copy --primary --type "$2" < "$1" 2>/dev/null || true
    if [ -n "$4" ]; then
        notify-send -i "$4" "Clipboard" "$3 — press Ctrl+V to paste" -t 2500
    else
        notify-send -i clipboard "Clipboard" "$3" -t 1500
    fi
}

paste_text() { # auto-paste text into the previously focused window
    (
        sleep 0.3
        CURRENT_CLASS=$(hyprctl activewindow -j 2>/dev/null | jq -r '.class // empty')
        TARGET="${CURRENT_CLASS:-$PREV_CLASS}"
        if [[ "$TARGET" =~ (ghostty|kitty|alacritty|foot|wezterm|terminal) ]]; then
            wtype -M ctrl -M shift -k v -m shift -m ctrl
        else
            wtype -M ctrl -k v -m ctrl
        fi
    ) &
}

if [[ "$selected" == *"||PIN:"* ]]; then
    id=${selected##*||PIN:}
    if [ -f "$PIN_DIR/$id.blob" ]; then
        mime=$(grep -o 'mime=[^ ]*' "$PIN_DIR/$id.meta" | cut -d= -f2)
        thumb=""; [ -f "$PIN_DIR/$id.thumb.png" ] && thumb="$PIN_DIR/$id.thumb.png"
        copy_file "$PIN_DIR/$id.blob" "$mime" "Pinned photo copied" "$thumb"
    elif [ -f "$PIN_DIR/$id.txt" ]; then
        copy_file "$PIN_DIR/$id.txt" "text/plain" "Pinned text copied & pasted"
        paste_text
    else
        notify-send "Clipboard" "Pin not found (deleted?)" -t 1500
    fi
    exit 0
fi

# History entry via cliphist
tmp=$(mktemp)
echo "$selected" | cliphist decode > "$tmp" 2>/dev/null
mime=$(file --mime-type -b "$tmp" 2>/dev/null || echo "text/plain")
wl-copy --type "$mime" < "$tmp"
wl-copy --primary --type "$mime" < "$tmp" 2>/dev/null || true

if echo "$mime" | grep -q 'text/'; then
    notify-send -i clipboard "Clipboard" "Copied & pasted" -t 1200
    paste_text
else
    thumb=$(mktemp --suffix=.png)
    if magick "$tmp[0]" -thumbnail 300x300 "$thumb" 2>/dev/null; then
        notify-send -i "$thumb" "Clipboard" "Photo copied — press Ctrl+V to paste" -t 3000
        (sleep 8; rm -f "$thumb" "$tmp") &
        exit 0
    else
        notify-send "Clipboard" "Photo copied — press Ctrl+V to paste" -t 2500
    fi
fi
rm -f "$tmp"
