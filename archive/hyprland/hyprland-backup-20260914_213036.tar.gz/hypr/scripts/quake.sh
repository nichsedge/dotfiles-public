#!/usr/bin/env bash
# Quake dropdown terminal. Toggle via SUPER+GRAVE (the ` key, top-left).
# Spawn is title-tagged (QUAKE); a window rule auto-places it floating in
# special:term, so this script never depends on window focus.
# NOTE: Hyprland runs in Lua mode — hyprctl uses `eval` with Lua expressions.
if hyprctl clients -j 2>/dev/null | jq -e '[.[] | select(.title == "QUAKE")] | length > 0' >/dev/null; then
    hyprctl eval "togglespecial('term')" >/dev/null
else
    hyprctl eval "hl.exec_cmd('ghostty --title=QUAKE')" >/dev/null
    sleep 0.8
    hyprctl eval "togglespecial('term')" >/dev/null
fi
