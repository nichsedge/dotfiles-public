#!/usr/bin/env bash
# Clipboard manager: pick a history entry, then Pin / Delete / Preview it,
# or wipe all history. Pins live in ~/.config/clipboard_pins (survive wipe).
# Bound to SUPER+CTRL+V.
PIN_DIR="$HOME/.config/clipboard_pins"
mkdir -p "$PIN_DIR"

entry=$(cliphist list 2>/dev/null | wofi --dmenu --prompt "Manage clip (pin/del/preview)" --width 650 --height 450)
[ -n "$entry" ] || exit 0
id=${entry%%$'\t'*}

action=$(printf '📌 Pin this\n👁 Preview\n🗑 Delete this\n🧹 Wipe ALL history' | wofi --dmenu --prompt "Action" --width 300 --height 250)
[ -n "$action" ] || exit 0

case "$action" in
    *Pin*)
        tmp=$(mktemp)
        echo "$entry" | cliphist decode > "$tmp" 2>/dev/null
        mime=$(file --mime-type -b "$tmp" 2>/dev/null || echo "text/plain")
        if echo "$mime" | grep -q 'text/'; then
            text=$(head -c 4000 "$tmp")
            pid=$(printf '%s' "$text" | sha256sum | cut -d' ' -f1 | head -c 16)
            if [ -f "$PIN_DIR/$pid.txt" ]; then
                notify-send "📌 Clipboard" "Already pinned" -t 1500
            else
                printf '%s' "$text" > "$PIN_DIR/$pid.txt"
                notify-send "📌 Clipboard" "Pinned: $(printf '%s' "$text" | head -1 | head -c 60)" -t 2000
            fi
        else
            pid=$(sha256sum "$tmp" | cut -d' ' -f1 | head -c 16)
            if [ -f "$PIN_DIR/$pid.blob" ]; then
                notify-send "📌 Clipboard" "Already pinned" -t 1500
            else
                dims=$(identify -format "%wx%h" "$tmp[0]" 2>/dev/null || echo "?")
                size=$(du -h "$tmp" | cut -f1)
                mv "$tmp" "$PIN_DIR/$pid.blob"
                echo "type=image mime=$mime dims=$dims size=$size" > "$PIN_DIR/$pid.meta"
                magick "$PIN_DIR/$pid.blob[0]" -thumbnail 200x200 "$PIN_DIR/$pid.thumb.png" 2>/dev/null
                notify-send -i "$PIN_DIR/$pid.thumb.png" "📌 Clipboard" "Pinned photo ($dims, $size)" -t 2000
                tmp=""
            fi
        fi
        [ -n "$tmp" ] && rm -f "$tmp"
        ;;
    *Preview*)
        tmp=$(mktemp --suffix=.png)
        echo "$entry" | cliphist decode > "$tmp" 2>/dev/null
        mime=$(file --mime-type -b "$tmp" 2>/dev/null || echo "text/plain")
        if echo "$mime" | grep -q 'text/'; then
            notify-send "Clipboard preview" "$(head -c 500 "$tmp")" -t 5000
            rm -f "$tmp"
        else
            # loupe floats via window rule; file stays in /tmp for the session
            loupe "$tmp" >/dev/null 2>&1 &
            disown
        fi
        ;;
    *Delete\ this*)
        echo "$id" | cliphist delete 2>/dev/null && notify-send "Clipboard" "Deleted entry $id" -t 1500
        ;;
    *Wipe*)
        confirm=$(printf 'Cancel\nYes, wipe all history (pins kept)' | wofi --dmenu --prompt "Sure?" --width 350 --height 150)
        if [[ "$confirm" == Yes* ]]; then
            cliphist wipe && notify-send "Clipboard" "History wiped, pins kept" -t 2000
        fi
        ;;
esac
