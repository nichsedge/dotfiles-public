#!/usr/bin/env bash
# Pin/unpin current clipboard (text or image). Toggle: run again to unpin.
# Bound to SUPER+SHIFT+V.
PIN_DIR="$HOME/.config/clipboard_pins"
mkdir -p "$PIN_DIR"

types=$(wl-paste --list-types 2>/dev/null)
if [ -z "$types" ]; then
    notify-send "Clipboard" "Clipboard empty" -t 1500
    exit 0
fi

imgtype=$(echo "$types" | grep -m1 -i '^image/')
if [ -n "$imgtype" ]; then
    tmp=$(mktemp)
    wl-paste --type "$imgtype" > "$tmp" 2>/dev/null
    if [ ! -s "$tmp" ]; then rm -f "$tmp"; notify-send "Clipboard" "Could not read image" -t 1500; exit 1; fi
    id=$(sha256sum "$tmp" | cut -d' ' -f1 | head -c 16)
    if [ -f "$PIN_DIR/$id.blob" ]; then
        rm -f "$PIN_DIR/$id.blob" "$PIN_DIR/$id.meta" "$PIN_DIR/$id.thumb.png"
        notify-send "📌 Clipboard" "Unpinned photo" -t 1500
    else
        dims=$(identify -format "%wx%h" "$tmp[0]" 2>/dev/null || echo "?")
        size=$(du -h "$tmp" | cut -f1)
        mv "$tmp" "$PIN_DIR/$id.blob"
        echo "type=image mime=$imgtype dims=$dims size=$size" > "$PIN_DIR/$id.meta"
        magick "$PIN_DIR/$id.blob[0]" -thumbnail 200x200 "$PIN_DIR/$id.thumb.png" 2>/dev/null
        notify-send -i "$PIN_DIR/$id.thumb.png" "📌 Clipboard" "Pinned photo ($dims, $size)" -t 2000
    fi
    rm -f "$tmp"
else
    text=$(wl-paste 2>/dev/null | head -c 4000)
    if [ -z "$text" ]; then notify-send "Clipboard" "Clipboard empty" -t 1500; exit 0; fi
    id=$(printf '%s' "$text" | sha256sum | cut -d' ' -f1 | head -c 16)
    if [ -f "$PIN_DIR/$id.txt" ]; then
        rm -f "$PIN_DIR/$id.txt"
        notify-send "📌 Clipboard" "Unpinned text" -t 1500
    else
        printf '%s' "$text" > "$PIN_DIR/$id.txt"
        label=$(printf '%s' "$text" | head -1 | head -c 60)
        notify-send "📌 Clipboard" "Pinned: $label" -t 2000
    fi
fi
